class VAT():

    def main(): 