# PyClusterTend

## Presentation : 

PTC is a python package to do cluster tendency evaluation. More information about cluster tendency 
evalution.

Two methods for assessing cluster tendency currently being implemented  :

- [x] Hoptinks Statistics :
- [ ] VAT : 

## Usage : 


## Support/Donation : 


Ismaël Lachheb :  https://paypal.me/lachhebo